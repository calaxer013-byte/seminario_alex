<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call([
            CatalogoSeeder::class,
            ConfiguracionAnexoSeeder::class,
            AnexoSeeder::class,
        ]);
    }
}
